colnames(seenow2)
## FEATURE SELECTION
data.for.cluster<-seenow2[,c("BuildingID","meternumb","Consumption","area_floor._m.sqr","normalizedConsumption","Base_Hour_Flag","Consumption_base","Base_Hour_Class")]


seenow3 <- split(seenow2, list(seenow2$BuildingID,seenow2$meternumb))
seenow4 <- seenow3[sapply(seenow3, function(x) dim(x)[1]) > 0]

split1 <- as.data.frame(seenow4[1])

### KMEANS ON ENTIRE DATA SET################################################################

nrow(data.for.cluster)
ncol(data.for.cluster)

str(data.for.cluster)

## CONVERTING FACTORIAL COLUMNS TO MATRICES/ 1 MATRIX
datamatrix.for.hcluster <- model.matrix(~.+0, data=data.for.cluster)

datamatrix.for.hcluster.split <- model.matrix(~.+0, data=split1)

## APPLYING HIERARCHIAL CLUST ENTIRE DATA SET ######################################################

hc.complete <- hclust(dist(datamatrix.for.hcluster), method="complete")
hc.average <- hclust(dist(datamatrix.for.hcluster), method="average")

par(mfrow=c(1,2))
plot(hc.complete,main="Complete")
plot(hc.average,main="Average")

cutree(hc.complete,3)
cutree(hc.average,3)

## APPLYING HIERARCHIAL CLUST on 1st frame ######################################################################

hc.complete.split <- hclust(dist(datamatrix.for.hcluster.split), method="complete")
hc.average.split <- hclust(dist(datamatrix.for.hcluster.split), method="average")

par(mfrow=c(1,2))
plot(hc.complete.split,main="Complete")
plot(hc.average.split,main="Average")

cutree(hc.complete,3)
cutree(hc.average,3)

