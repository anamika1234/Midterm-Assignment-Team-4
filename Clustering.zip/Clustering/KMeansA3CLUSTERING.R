## START OF CODE
colnames(seenow2)
## FEATURE SELECTION
data.for.cluster<-seenow2[,c("BuildingID","meternumb","Consumption","area_floor._m.sqr","normalizedConsumption","Base_Hour_Flag","Consumption_base","Base_Hour_Class")]


### KMEANS ON ENTIRE DATA SET################################################################
nrow(data.for.cluster)
str(data.for.cluster)
#View(data.for.cluster)
ncol(data.for.cluster)


## CONVERTING FACTORIAL COLUMNS TO MATRICES/ 1 MATRIX
datamatrix.for.cluster <- model.matrix(~.+0, data=data.for.cluster)
nrow(datamatrix.for.cluster)

## APPLYING KMEANS
data.for.kmeans <- kmeans(datamatrix.for.cluster, 2, nstart = 10)

##  MISC CHECKS
names(data.for.kmeans)
data.for.kmeans$betweenss
data.for.kmeans$size
data.for.kmeans
#plot(data.for.kmeans, col=(data.for.kmeans$cluster))

clustering.accuracy <- table(data.for.kmeans$cluster, data.for.cluster$Base_Hour_Class)
(clustering.accuracy[1]+clustering.accuracy[4])/nrow(data.for.cluster)

## CHECKING BEND CURVE BASED ON WITHIN SUM OF SQUARES
wss <- nrow((datamatrix.for.cluster)-1)*sum(apply(datamatrix.for.cluster,2,var))
for(i in 2:15){
  wss[i] <- sum(kmeans(datamatrix.for.cluster,centers = i)$withinss)
}

## PLOTTING BEND CURVE
plot(1:15, wss, type="b")






######JUST BASE HOUR FLAG AND BASE HOUR USAGE AS FEATURES ON ENTIRE DATA#########################

newdata.cluster <- seenow2[,c("Base_Hour_Flag","Consumption_base","Base_Hour_Class")]

nrow(newdata.cluster)
str(newdata.cluster)
newdata.matrix <- model.matrix(~.+0, data=newdata.cluster)

newdata.for.kmeans <- kmeans(newdata.matrix, 3, nstart = 10)

newdata.for.kmeans$size
data.for.kmeans$withinss
newdata.for.kmeans

newdata.predictiontry <- table(newdata.for.kmeans$cluster, newdata.cluster$Base_Hour_Class)
(newdata.predictiontry[1]+newdata.predictiontry[4])/nrow(newdata.cluster)

## CHECKING BEND CURVE BASED ON WITHIN SUM OF SQUARES
newwss <- nrow((newdata.matrix)-1)*sum(apply(newdata.matrix,2,var))
for(i in 2:15){
  newwss[i] <- sum(kmeans(newdata.matrix,centers = i)$withinss)
}

## PLOTTING BEND CURVE
plot(1:15, newwss, type="b")



