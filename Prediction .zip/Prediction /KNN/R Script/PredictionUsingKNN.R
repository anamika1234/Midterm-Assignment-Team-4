
###########################################################################################################
##################################### Prediction : using KNN ##########################################################
###########################################################################################################
install.packages("dummies")
install.packages("FNN")
install.packages("scales")
install.packages("caret")
install.packages("rknn")


library(dummies)
library(FNN)
library(scales)
library(caret)
library(rknn)

ii<- 1
model <- NULL
modelFull <- NULL

for(ii in seq(1:length(seenow4))){
  predcheck <- NULL  
  predcheck <- as.data.frame(seenow4[[ii]])
 
#======================= REMOVING UNWANTED COLUMNS ============================================


predcheck[["DateUTC"]] <- NULL
predcheck[["Events"]] <- NULL
predcheck[["PrecipitationIn"]] <- NULL
predcheck[["Time"]] <- NULL
predcheck[["dateTime"]] <- NULL
predcheck[["X"]] <- NULL              #Not required
predcheck[["vac"]] <- NULL            #Not required
predcheck[["date"]] <- NULL           #Not required

buildingID <- predcheck[["BuildingID"]]
meternum <- predcheck[["meternumb"]]

predcheck[["BuildingID"]] <- NULL     #Col has only 1 type
predcheck[["meternumb"]] <- NULL      #Col has only 1 type

predcheck[["type"]] <- NULL           #Col has only 1 type 
predcheck[["Gust_SpeedMPH"]] <- NULL  #Col has no data
predcheck[["Consumption"]] <- NULL  #Not required since the normalised column of this data is being predicted
predcheck[["Consumption_base"]] <- NULL  #Not required since the normalised column of this data is being predicted

predcheck[["WindDirDegrees"]] <- NULL
predcheck[["Wind_Direction"]] <- NULL  #this column can be removed as WindDirDegrees represnts this data in numbers

#======================= CONVERTING CATEGORICAL VARIABLES TO FACTOR ============================================

predcheck[["hour"]] <- as.factor(predcheck[["hour"]])
predcheck[["dayofWeek_"]] <- as.factor(predcheck[["dayofWeek_"]])
predcheck[["monthofYear"]] <- as.factor(predcheck[["monthofYear"]])
predcheck[["isWeekend"]] <- as.factor(predcheck[["isWeekend"]])
predcheck[["Base_Hour_Class"]] <- as.factor(predcheck[["Base_Hour_Class"]])
predcheck[["Conditions"]] <- as.factor(predcheck[["Conditions"]])


#======================= RESCALING NUMERIC COLUMNS ============================================

predcheck$Temperature <- rescale(predcheck$Temperature)
predcheck$Dew_PointF <- rescale(predcheck$Dew_PointF)
predcheck$Humidity <- rescale(predcheck$Humidity)
predcheck$Sea_Level_PressureIn <- rescale(predcheck$Sea_Level_PressureIn)
predcheck$VisibilityMPH <- rescale(predcheck$VisibilityMPH)
predcheck$Wind_SpeedMPH <- rescale(predcheck$Wind_SpeedMPH)
predcheck$area_floor._m.sqr <- rescale(predcheck$area_floor._m.sqr)
predcheck$Base_Hour_Flag <- rescale(predcheck$Base_Hour_Flag)
predcheck$holiday <- rescale(predcheck$holiday)
predcheck$Base_Hr_Usage <- rescale(predcheck$Base_Hr_Usage)
predcheck$Base_Hour_Class <- ifelse(predcheck$Base_Hour_Class == "High", TRUE, FALSE)
predcheck$Base_Hour_Class <- rescale(predcheck$Base_Hour_Class)
predcheck$isWeekend <- ifelse(predcheck$isWeekend == "1", TRUE, FALSE)

predcheck$isWeekend  <- rescale(predcheck$isWeekend)

#======================= REMOVING COLUMNS THAT ADD LESS IMPORTANCE TO PREDICTION ============================================
#======================= REMOVING FACTORIAL VARIABLES AS THEIR DUMMY VARIABLES FAILED TO PREDICT ============================================

#predcheck[["Dew_PointF"]] <- NULL
predcheck[["Base_Hour_Class"]] <- NULL
predcheck[["monthofYear"]] <- NULL
predcheck[["Conditions"]] <- NULL
predcheck[["hour"]] <- NULL
predcheck[["dayofWeek_"]] <- NULL
#predcheck[["Wind_SpeedMPH"]] <- NULL
predcheck[["isWeekend"]] <- NULL
#predcheck[["Humidity"]] <- NULL
predcheck[["VisibilityMPH"]] <- NULL
predcheck[["holiday"]] <- NULL
predcheck[["area_floor._m.sqr"]] <- NULL
predcheck[["Base_Hr_Usage"]] <- NULL
predcheck[["Base_Hour_Flag"]] <- NULL

predcheck$X5198.2.normalizedConsumption <- predcheck$normalizedConsumption
predcheck$normalizedConsumption <- NULL
predcheck$normalizedConsumption <- predcheck$X5198.2.normalizedConsumption
predcheck$X5198.2.normalizedConsumption <- NULL
str(predcheck)

#======================= THIS LINE OF CODE WAS USED FOR CONVERTING FACTORIAL VARIABLES INTO DUMMY VARIABLES ============================================

#predcheck <- model.matrix(~.+0, data=predcheck)

#======================= CREATING TRAIN AND TEST DATA ============================================

set.seed(1000)
t.idx <- createDataPartition(predcheck[,"normalizedConsumption"], p = 0.6, list = FALSE)

trg <- predcheck[t.idx,]
rest <- predcheck[-t.idx,]
set.seed(2000)
v.idx <- createDataPartition(predcheck[,"normalizedConsumption"], p=0.5, list=FALSE)
val <- predcheck[v.idx,]
test <- predcheck[-v.idx,]

#======================= GENERATING PREDICTIONS ============================================

res.test <- knn.reg(trg[, 1:5], test[,1:5], trg[,6], 4)

#plot(test$normalizedConsumption, res.test$pred)

#======================= CREATING RESIDUALS ============================================
final <- NULL
final$testData <- test$normalizedConsumption
final$prediction <- res.test$pred

final$residuals <- test$normalizedConsumption - res.test$pred

#======================= CALCULATING RMSE, MAE ============================================

rmse.test = sqrt(mean((res.test$pred-test[,6])^2))
model$BuildingID <- buildingID[1]
model$meternumb <- meternum[1]
model$rmse = sqrt(mean((res.test$pred-test[,6])^2))

model$mae <- mean(abs(res.test$pred-test[,6] ))

model$modelString <- "res.test <- knn.reg(trg[1:5] test[1:5] trg[6] 4)"

modelFull <-rbind(modelFull, model)


#======================= TAGING OUTLIERS ============================================

standardDeviation <- sd(final$residuals)

final$outliers <- ifelse(final$residuals >= 2*standardDeviation, "1", "")


test$prediction <- res.test$pred
test$outliers <- final$outliers


abc <- NULL
xyz <- NULL
for (i in seq(1:nrow(test))){
  abc <- rbind(abc,buildingID[1])
}
for (y in seq(1:nrow(test))){
  xyz <- rbind(xyz,meternum[1])
}
test$BuildingID <- abc
test$meternumb <- xyz

#======================= WRITTING 78 MODELS INTO CSV ============================================

write.csv(test,paste("KNNPredictionData",ii,".csv",sep =""))

}
write.csv(modelFull,paste("KNNPredictionModel.csv",sep =""))
