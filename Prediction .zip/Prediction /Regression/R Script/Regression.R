install.packages("car")
install.packages("forecast")

library(car)
library(forecast)

ii<- 1
model <- NULL
modelFull <- NULL

for(ii in seq(1:length(seenow4))){
  regcheck <- NULL  
  regcheck <- as.data.frame(seenow4[[4]])

set.seed(150)

data_NN <- regcheck

apply(data_NN,2,function(x) sum(is.na(x)))

data_NN$vac <- as.character(data_NN$vac)
data_NN$type <- as.character(data_NN$type)
#data_NN$PrecipitationIn <- as.numeric(data_NN$PrecipitationIn)
data_NN$date <- as.Date(data_NN$date)
#data_NN$dateTime <- as.Date(data$dateTime)
#data_NN$DateUTC <- as.Date(data_NN$DateUTC)
#data_NN$Time <- as.Date(data_NN$Time)

data_NN[["vac"]] <- NULL
data_NN[["X"]] <- NULL
data_NN[["type"]] <- NULL

index <- sample(1:nrow(data_NN),round(0.75*nrow(data_NN)))
train <- data_NN[index,]
test <- data_NN[-index,]

#summary(train[3])

#lm.fit <- lm(normalizedConsumption ~.-Gust_SpeedMPH-X-vac-type -meternumb-BuildingID , data=train)
#hour + BuildingID + meternumb + hour + dayofWeek_ + monthofYear + isWeekend + Temperature + Dew_PointF + Humidity + Sea_Level_PressureIn + VisibilityMPH + Wind_SpeedMPH + WindDirDegrees


lm.fit <- lm(normalizedConsumption ~ hour + Consumption
             +monthofYear +holiday
             +Base_Hour_Flag + VisibilityMPH
             +Consumption_base, data=train)
summary(lm.fit)

################### Getting all coefficients  #########
RegressionOutput <- summary(lm.fit)$coefficients[,1]

################### Getting 1 coefficient  #########
coef(summary(lm.fit))["date","Estimate"]

vif(lm.fit)

pred=predict(lm.fit,test)

#library("forecast")
accuracyMatrix <- accuracy(pred,train$normalizedConsumption)
t(accuracyMatrix)

################## CHECKING FIT OF ALL THE VARIABLES #########

lm.fit1 = lm(normalizedConsumption~ ., data=train, na.action = na.omit)
summary(lm.fit1)

pred1=predict(lm.fit1,test)
t(accuracy(pred1,train$normalizedConsumption))


#################### PREDICTING THE Energy#########################################

pred=predict(lm.fit,test)

################ PLOTS BASED ON FITS ###############

plot(lm.fit)


################ CHECKING ACCURACY ###################

t(accuracy(pred,test$normalizedConsumption))

#View(test)


#str(train)

#apply(data_NN,2,function(x) sum(is.na(x)))



#======================= CREATING RESIDUALS ============================================
final <- NULL
final$testData <- test$normalizedConsumption
final$prediction <- pred

final$residuals <- test$normalizedConsumption - pred

#======================= CALCULATING RMSE, MAE ============================================

model$BuildingID <- test$BuildingID[1]
model$meternumb <- test$meternumb[1]

acc <- (accuracy(pred,test$normalizedConsumption))
model$RMSE <-  acc[2]

model$mae <- acc[3]
model$mape <- acc[5]
model$modelString <- "lm.fit <- lm(normalizedConsumption ~ hour + Consumption +monthofYear +holiday +Base_Hour_Flag + VisibilityMPH+Consumption_base, data=train)"

modelFull <-rbind(modelFull, model)


#======================= TAGING OUTLIERS ============================================

standardDeviation <- sd(final$residuals)

final$outliers <- ifelse(final$residuals >= 2*standardDeviation, "1", "0")


test$prediction <- pred
test$outliers <- final$outliers



#======================= WRITTING 78 MODELS INTO CSV ============================================

write.csv(test,paste("RegressionData",ii,".csv",sep =""))

}
write.csv(modelFull,paste("RegressionModel.csv",sep =""))

