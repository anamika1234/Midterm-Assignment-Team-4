Sys.setenv(JAVA_HOME='C:\\Program Files\\Java\\jre1.8.0_101')
library(caret)
library(randomForest)
library(e1071)
library(rJava)
library(xlsx)
library(XLConnect)
install.packages("neuralnet")
library(neuralnet)


ii<- 1
accuracy.data.frame <- NULL

rf.Model.List <-  vector("list",length(seenow4))


for(ii in seq(1:length(seenow4))){
  
  current.data.frame <- seenow4[[ii]]
  str(current.data.frame)
  set.seed(1234567890)
  current.data.frame$Base_Hour_Class
  check <- current.data.frame[sapply(current.data.frame, function(x) length(unique(x))==1)]
  #check
  
  if(names(check)[ncol(check)] == "Base_Hour_Class"){
    if(current.data.frame$Base_Hour_Class[1]== "High"){
      current.data.frame[1,"Base_Hour_Class"]<-"Low"
      print("yes changed to low")
    } else if(current.data.frame$Base_Hour_Class[1]== "Low"){
      current.data.frame[1,"Base_Hour_Class"]<-"High"
      print("yes changed to high")
    }
  }
  
  consumption_NN <- model.matrix(~.+0, data=current.data.frame)
  
  index <- sample(1:nrow(consumption_NN),round(0.75*nrow(consumption_NN)))
  train_NN <- consumption_NN[index,]
  test_NN <- consumption_NN[-index,]
  
  str(train_NN)
  
  net_consumption_NN <- neuralnet(normalizedConsumption ~ hour + Consumption
                                  + Base_Hour_FlagTRUE + VisibilityMPH
                                  + Consumption_base,train_NN, hidden = 4,
                                  lifesign = "minimal", linear.output = FALSE, threshold = 0.1)
  
  
  
  plot(net_consumption_NN, rep = "best")
  
  temp_test <- subset(test_NN, select = c("hour", "Consumption","Base_Hour_FlagTRUE", "VisibilityMPH","Consumption_base"))
  View(temp_test)
  net_consumption_NN.results <- compute(net_consumption_NN, temp_test)
  #is.data.frame(net_consumption_NN.results)
  #View(net_consumption_NN.results)
  
  #current.data.frame$normalizedConsumption
  Predicted.Normalized.Consumption <- data.frame(actual = test_NN[, "normalizedConsumption"], prediction = net_consumption_NN.results$net.result)
  final_tested_data_with_prediction <- cbind(temp_test,Predicted.Normalized.Consumption)
  

  #is.data.frame(results)
  #summary(net_consumption_NN.results$net.result)
  
  write.csv(final_tested_data_with_prediction,paste("NNModelPrediction",ii,".csv",sep =""))
  
  model <- NULL
  
  model$rmse = sqrt(mean((final_tested_data_with_prediction$prediction-final_tested_data_with_prediction$actual)^2))
  
  model$mae <- mean(abs(final_tested_data_with_prediction$prediction - final_tested_data_with_prediction$actual ))
  
  write.csv(model,paste("NNModelMAE_RMSE",ii,".csv",sep =""))
  

}

 