#seenow2 <- read.csv(file = "seenow2.csv" , header = TRUE, stringsAsFactors = FALSE)
#=======================TRYING TO CREATE SETS OF DATA============================================
#"SPLIT FUNCTION" - rawData, (BUILDING ID + METER NUMBER) - 72 , 5 ==============================

seenow3 <- split(seenow2, list(seenow2$BuildingID,seenow2$meternumb))

seenow4 <- seenow3[sapply(seenow3, function(x) dim(x)[1]) > 0]


###########################################################################################################
##################################### Prediction : Using Random Forest ##########################################################
###########################################################################################################

install.packages("randomForest")
install.packages("miscTools")
install.packages("ggplot2")
install.packages("tree")
install.packages("glmm")
install.packages("caret")
install.packages("hydroGOF")
install.packages("CORElearn")
install.packages("e1071")
install.packages("rJava")
install.packages("xlsx")
install.packages("XLConnect")

library(randomForest)
library(miscTools)
library(ggplot2)
library(tree)
library(forecast)
library(glmm)
library(caret)
library(hydroGOF)
library(CORElearn)
library(e1071)
library(rJava)
library(xlsx)
library(XLConnect)

ii<- 1
model <- NULL
modelFull <- NULL
for(ii in seq(1:length(seenow4))){
  rdcheck <- NULL  
rdcheck <- as.data.frame(seenow4[[ii]])


rdcheck[["DateUTC"]] <- NULL
rdcheck[["Events"]] <- NULL
rdcheck[["PrecipitationIn"]] <- NULL
rdcheck[["Time"]] <- NULL
rdcheck[["dateTime"]] <- NULL

rdcheck[["X"]] <- NULL              #Not required
rdcheck[["vac"]] <- NULL            #Not required
rdcheck[["date"]] <- NULL           #Not required
#rdcheck[["BuildingID"]] <- NULL     #Col has only 1 type
#rdcheck[["meternumb"]] <- NULL      #Col has only 1 type
rdcheck[["type"]] <- NULL           #Col has only 1 type 
rdcheck[["Gust_SpeedMPH"]] <- NULL  #Col has no data
rdcheck[["Consumption"]] <- NULL  #Not required since the normalised column of this data is being predicted
rdcheck[["Consumption_base"]] <- NULL  #Not required since the normalised column of this data is being predicted


#======================= Removing for temporary purpose ============================================

rdcheck[["WindDirDegrees"]] <- NULL
rdcheck[["Wind_Direction"]] <- NULL  #this column can be removed as WindDirDegrees represnts this data in numbers


#======================= Converting columns as factor ============================================

rdcheck[["hour"]] <- as.factor(rdcheck[["hour"]])
rdcheck[["dayofWeek_"]] <- as.factor(rdcheck[["dayofWeek_"]])
rdcheck[["monthofYear"]] <- as.factor(rdcheck[["monthofYear"]])
rdcheck[["isWeekend"]] <- as.factor(rdcheck[["isWeekend"]])
rdcheck[["Base_Hour_Class"]] <- as.factor(rdcheck[["Base_Hour_Class"]])
rdcheck[["Conditions"]] <- as.factor(rdcheck[["Conditions"]])

#===  CASE 1: when all variables include errorpercent -0.03530304 ===


#varImpPlot(rf)

missClass = function(values, prediction) {
  sum(prediction - values)/length(values)
}


#===  CASE 2: Keeping top 5 variables, and removing variables with less importance ===
rdcheck[["Dew_PointF"]] <- NULL
rdcheck[["Temperature"]] <- NULL
rdcheck[["Conditions"]] <- NULL
rdcheck[["Wind_SpeedMPH"]] <- NULL
rdcheck[["isWeekend"]] <- NULL
rdcheck[["Humidity"]] <- NULL
rdcheck[["VisibilityMPH"]] <- NULL
rdcheck[["holiday"]] <- NULL
rdcheck[["area_floor._m.sqr"]] <- NULL
rdcheck[["Base_Hr_Usage"]] <- NULL
rdcheck[["Base_Hour_Class"]] <- NULL



  index <- sample(1:nrow(rdcheck),round(0.75*nrow(rdcheck)))
  train <- rdcheck[index,]
  test <- rdcheck[-index,]
  
  train[["BuildingID"]] <- NULL     #Col has only 1 type
  train[["meternumb"]] <- NULL      #Col has only 1 type
  
  buildingID <- test[["BuildingID"]]
  meternum <- test[["meternumb"]]
  
  
  test[["BuildingID"]] <- NULL     #Col has only 1 type
  test[["meternumb"]] <- NULL      #Col has only 1 type
  
  
  
  rf <- randomForest(normalizedConsumption ~ ., data=train, ntree=20)
  predicted <- predict(rf, newdata=test[,-6])
  
  
  
  oob = missClass(test$normalizedConsumption, predicted)
  oobPercent = oob*100
  
  #===================================RMSE, MAE===========================================
  
  
  model$BuildingID <- buildingID[1]
  model$meternumb <- meternum[1]
  model$rmse = sqrt(mean((predicted-test$normalizedConsumption)^2))
  
  model$mae <- mean(abs(predicted - test$normalizedConsumption ))
  
  #===================================PREDICTIONS, RESIDUALS, STANDARD DEVIATION, OUTLIERS ===========================================
  
  final <- NULL
  final$testData <- test$normalizedConsumption
  final$prediction <- predicted
  
  final$residuals <- test$normalizedConsumption - predicted
  
  
  #======================= TAGING OUTLIERS ============================================
  
  standardDeviation <- sd(final$residuals)
  
  final$outliers <- ifelse(final$residuals >= 2*standardDeviation, "1", "0")
  View(test)
  test$prediction <- predicted
  test$outliers <- final$outliers
  test$BuildingID <- buildingID[1]
  test$meternumb <- meternum
  write.csv(test,paste("RFPredictionData",ii,".csv",sep =""))
  model$string <- "rf <- randomForest(normalizedConsumption ~ ., data=train, ntree=20)"
  
  modelFull <-rbind(modelFull, model)
  
}
write.csv(modelFull,paste("RFPredictionModel.csv",sep =""))



#md <- CoreModel(normalizedConsumption ~ ., train, model="rf", rfNoTrees=20)
#outliers <- rfOutliers(md, train)
#plot(abs(outliers))
#for a nicer display try 
#plot(md, train, graphType="outliers")


#======================================= PLOT ============================================================

plot(test$normalizedConsumption, predicted)


#=========================================Extra IGRORE !!!!!!!! =====================================================
#r2 <- rSquared(test$normalizedConsumption, test$normalizedConsumption - predict(rf, test[,-16]))
#str(test)
#p <- ggplot(aes(x=actual, y=pred),
#            data=data.frame(actual=test$normalizedConsumption, pred=predict(rf, test[,-6])))

##p + geom_point() +
#  geom_abline(color="red") +
#  ggtitle(paste("RandomForest Regression in R r^2=", r2, sep=""))





#=======================PLOT ============================================

#qqnorm((predicted - test$normalizedConsumption)/sd(predicted-test$normalizedConsumption))

#qqline((predicted - test$normalizedConsumption)/sd(predicted-test$normalizedConsumption))

#plot(test$normalizedConsumption, predicted)





